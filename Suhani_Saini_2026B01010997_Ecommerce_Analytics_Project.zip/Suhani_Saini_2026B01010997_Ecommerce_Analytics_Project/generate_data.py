import numpy as np
import pandas as pd

np.random.seed(42)
n = 60

df = pd.DataFrame({
    "Order_ID": [f"ORD{1000 + i}" for i in range(n)],
    "Order_Date": pd.date_range(start="2025-01-01", periods=n, freq="D"),
    "Customer_ID": np.random.choice(
        [f"CUST_{c}" for c in range(1, 31)], size=n
    ),
    "Category": np.random.choice(
        ["Electronics", "Fashion", "Home & Kitchen", "Books", "Beauty"],
        size=n,
    ),
    "Quantity": np.random.randint(1, 6, size=n),
    "Sales": np.round(np.random.uniform(500, 20000, size=n), 2),
    "Discount": np.random.choice([0.0, 0.05, 0.10, 0.20, 0.30], size=n),
})

df["Profit"] = np.round(
    df["Sales"] * (0.28 - df["Discount"] * 0.65)
    + np.random.normal(0, 400, size=n),
    2,
)

df.to_csv("data/ecommerce_sales.csv", index=False)
print("Dataset successfully created inside data/ecommerce_sales.csv!")