from analytics import generate_summary_report
from operations import (
    add_record,
    delete_record,
    display_records,
    search_record,
    update_record,
)
from utils import CATEGORIES, format_inr


def print_header(title):
    print("\n" + "=" * 62)
    print(title.center(62))
    print("=" * 62)


def show_summary_report():
    report = generate_summary_report()
    np_res = report["np_results"]

    print_header("SUMMARY REPORT & DATA ANALYSIS")
    print(f"Total Records   : {np_res['count']}")
    print(f"Total Sales     : {format_inr(np_res['sales_sum'])}")
    print(f"Average Sales   : {format_inr(np_res['sales_mean'])}")
    print(f"Highest Sales   : {format_inr(np_res['sales_max'])}")
    print(f"Lowest Sales    : {format_inr(np_res['sales_min'])}")
    print(f"Sales Std Dev   : {format_inr(np_res['sales_std'])}")
    print(f"Total Profit    : {format_inr(np_res['profit_sum'])}")
    print(f"Average Profit  : {format_inr(np_res['profit_mean'])}")
    print(f"Profit Std Dev  : {format_inr(np_res['profit_std'])}")

    print("\n--- NumPy Arrays & Slicing ---")
    print("1D Array Slice (first 3 sales):", np_res["first_3_sales"])
    print("2D Array Slice (first 5 rows [Sales, Profit]):")
    print(np_res["first_5_2d_slice"])

    print("\n--- Pandas Statistical Summary ---")
    print(report["describe"].round(2).to_string())

    print("\n--- Category-wise Performance ---")
    print(report["category_summary"].round(2).to_string(index=False))

    print("\n--- Discount Impact on Average Sales & Profit ---")
    print(report["discount_summary"].round(2).to_string(index=False))

    print("\n--- Top High-Value Orders (Sales >= Rs.10,000) ---")
    print(report["high_sales_df"].to_string(index=False))

    print("\n--- Key Insights ---")
    for i, item in enumerate(report["insights"], start=1):
        print(f"{i}. {item}")


def main():
    while True:
        print_header("E-COMMERCE SALES & CUSTOMER ANALYTICS")
        print("1. Add a new record")
        print("2. Display all records")
        print("3. Search for a record")
        print("4. Update an existing record")
        print("5. Delete a record")
        print("6. Generate summary report")
        print("7. Exit")

        choice = input("\nEnter your choice (1-7): ").strip()

        if choice == "1":
            order_id = input("Enter Order ID (e.g., ORD1099): ").strip()
            cust_id = input("Enter Customer ID (e.g., CUST_12): ").strip()
            print("Available Categories:", ", ".join(CATEGORIES))
            category = input("Enter Category: ").strip()
            try:
                qty = int(input("Enter Quantity: ").strip())
                sales = float(input("Enter Sales: ").strip())
                discount = float(input("Enter Discount (e.g., 0.10): ").strip())
                ok, msg = add_record(order_id, cust_id, category, qty, sales, discount)
                print(msg)
            except ValueError:
                print("Please enter valid numeric values for Quantity, Sales, and Discount.")

        elif choice == "2":
            df = display_records()
            print_header(f"ALL RECORDS ({len(df)} rows)")
            print(df.to_string(index=False))

        elif choice == "3":
            order_id = input("Enter Order ID to search: ").strip()
            found = search_record(order_id)
            if found.empty:
                print("Record not found.")
            else:
                print_header("RECORD FOUND")
                print(found.to_string(index=False))

        elif choice == "4":
            order_id = input("Enter Order ID to update: ").strip()
            sales_str = input("Enter new Sales (press Enter to skip): ").strip()
            disc_str = input("Enter new Discount (press Enter to skip): ").strip()
            try:
                new_sales = float(sales_str) if sales_str else None
                new_disc = float(disc_str) if disc_str else None
                ok, msg = update_record(order_id, new_sales, new_disc)
                print(msg)
            except ValueError:
                print("Invalid number entered.")

        elif choice == "5":
            order_id = input("Enter Order ID to delete: ").strip()
            ok, msg = delete_record(order_id)
            print(msg)

        elif choice == "6":
            show_summary_report()

        elif choice == "7":
            print("Exiting program.")
            break

        else:
            print("Invalid choice. Enter a number from 1 to 7.")


if __name__ == "__main__":
    main() 