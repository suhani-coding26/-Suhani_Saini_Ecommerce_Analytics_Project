import pandas as pd
from utils import CATEGORIES, load_dataset, save_dataset


def add_record(order_id, customer_id, category, quantity, sales, discount):
    """Add a new record to the dataset."""
    df = load_dataset()

    if order_id in df["Order_ID"].astype(str).values:
        return False, f"Order ID '{order_id}' already exists."

    if category not in CATEGORIES:
        return False, f"Category must be one of: {', '.join(CATEGORIES)}"

    profit = round(float(sales) * (0.28 - float(discount) * 0.65), 2)

    # Dictionary representing a new row
    new_record = {
        "Order_ID": order_id,
        "Order_Date": pd.Timestamp.today().strftime("%Y-%m-%d"),
        "Customer_ID": customer_id,
        "Category": category,
        "Quantity": int(quantity),
        "Sales": round(float(sales), 2),
        "Discount": float(discount),
        "Profit": profit,
    }

    df = pd.concat([df, pd.DataFrame([new_record])], ignore_index=True)
    save_dataset(df)
    return True, f"Record '{order_id}' added successfully."


def display_records():
    """Display all records."""
    return load_dataset()


def search_record(order_id):
    """Search a record by Order_ID."""
    df = load_dataset()
    return df[df["Order_ID"].astype(str).str.upper() == order_id.strip().upper()]


def update_record(order_id, new_sales=None, new_discount=None):
    """Update sales and/or discount of an existing record."""
    df = load_dataset()
    matches = df.index[df["Order_ID"].astype(str).str.upper() == order_id.strip().upper()]

    if len(matches) == 0:
        return False, f"No record found with Order ID '{order_id}'."

    idx = matches[0]
    sales_val = float(new_sales) if new_sales is not None else float(df.loc[idx, "Sales"])
    disc_val = float(new_discount) if new_discount is not None else float(df.loc[idx, "Discount"])

    df.loc[idx, "Sales"] = round(sales_val, 2)
    df.loc[idx, "Discount"] = disc_val
    df.loc[idx, "Profit"] = round(sales_val * (0.28 - disc_val * 0.65), 2)

    save_dataset(df)
    return True, f"Record '{order_id}' updated successfully."


def delete_record(order_id):
    """Delete a record by Order_ID."""
    df = load_dataset()
    keep_mask = df["Order_ID"].astype(str).str.upper() != order_id.strip().upper()

    if keep_mask.sum() == len(df):
        return False, f"No record found with Order ID '{order_id}'."

    df = df[keep_mask].reset_index(drop=True)
    save_dataset(df)
    return True, f"Record '{order_id}' deleted successfully." 