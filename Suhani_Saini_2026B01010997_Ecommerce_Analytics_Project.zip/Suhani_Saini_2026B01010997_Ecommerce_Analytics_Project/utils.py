import pandas as pd

CSV_FILE = "data/ecommerce_sales.csv"

# Data structures: Tuple & List
CATEGORIES = ("Electronics", "Fashion", "Home & Kitchen", "Books", "Beauty")
DISCOUNT_SLABS = [0.0, 0.05, 0.10, 0.20, 0.30]


def load_dataset():
    """Read dataset from CSV file."""
    df = pd.read_csv(CSV_FILE)
    if "Order_Date" in df.columns:
        df["Order_Date"] = pd.to_datetime(df["Order_Date"], errors="coerce")
    return df


def save_dataset(df):
    """Save DataFrame back to CSV file."""
    df.to_csv(CSV_FILE, index=False)


def get_unique_categories(df):
    """Return a set of unique categories."""
    return set(df["Category"].dropna().astype(str).tolist())


def format_inr(amount):
    """Format amount cleanly."""
    return f"Rs.{float(amount):,.2f}" 